package br.com.acme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CondominioAcmeApplicationTests {

	@Test
	void contextLoads() {
	}

}
